<div class="footer">
            <div class="container">
                <div class="footer-top">
                    <h2 style="color: white">Quick Links</h2>
                     <br />
                   
                                            
                        <li><a href="index.php"><strong style="color: white">
                        Home</strong></a></li>
                        <li><a href="admin/signin.php"><strong style="color: white">Admin</strong></a></li>
                        <li><a href="police/signin.php"><strong style="color: white">Police</strong></a></li>
                        <li><a href="user/signin.php"><strong style="color: white">User</strong></a></li>
                       
           
                </div>
            </div>
        </div>