  <aside id="sidebar-left" class="sidebar-left">
        
          <div class="sidebar-header">
            <div class="sidebar-title">
              Navigation
            </div>
            <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
              <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
            </div>
          </div>
        
          <div class="nano">
            <div class="nano-content">
              <nav id="menu" class="nav-main" role="navigation">
                <ul class="nav nav-main">
                  <li class="nav-active">
                    <a href="dashboard.php">
                      <i class="fa fa-home" aria-hidden="true"></i>
                      <span>Dashboard</span>
                    </a>
                  </li>
                  <li>
                    <a href="fir-form.php">
                     <i class="fa fa-envelope" aria-hidden="true"></i>
                      <span>FIR Form</span>
                    </a>
                  </li>
                  <li>
                    <a href="fir-history.php">
                      <i class="fa fa-table" aria-hidden="true"></i>
                      <span>FIR History</span>
                    </a></li>
                   
                 
                  
           <li>
                    <a href="chargesheet.php">
                     <i class="fa fa-columns" aria-hidden="true"></i>
                      <span>Charge Sheet</span>
                    </a>
                  </li>
           
                  <li>
                    <a href="search.php">
                      <i class="fa fa-search" aria-hidden="true"></i>
                      <span>Search</span>
                    </a>
                 
                  </li>
          
         
                </ul>
              </nav>
             
            </div>
        
          </div>
        
        </aside>